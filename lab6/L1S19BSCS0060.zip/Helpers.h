#pragma once
#include<iostream>

int strLength(const char*);
void deepCopy(char*&, const char*);
