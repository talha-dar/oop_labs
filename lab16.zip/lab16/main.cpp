#include<iostream>
#include"BankDatabase.h"
#include"BankDatabase.cpp"
#include"CheckingAccount.h"
#include"CheckingAccount.cpp"
#include"SavingsAccount.h"
#include"SavingsAccount.cpp"
using namespace std;

int main(){
  BankDatabase db1(5);
  cout<<"\nHello there.";
  return 0;
}
