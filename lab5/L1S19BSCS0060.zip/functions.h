#pragma once
#include<iostream>
using namespace std;

int len(const char*);
void strCopy(char*&, const char*);
